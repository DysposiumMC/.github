<?php

declare(strict_types=1);

namespace PrideCore\Utils;

class RankManager {
	
}