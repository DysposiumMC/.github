<?php

declare(strict_types = 1);

namespace PrideCore\Utils\Forms;

use pocketmine\plugin\PluginBase;

class Forms extends PluginBase{

}
