# PrideCore
PrideCore Plugin (Discontinued)
